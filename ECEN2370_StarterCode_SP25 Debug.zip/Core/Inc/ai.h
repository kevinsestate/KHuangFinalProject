#ifndef AI_H
#define AI_H

#include <stdint.h>

int8_t GetSmartAIMove(void);

#endif
