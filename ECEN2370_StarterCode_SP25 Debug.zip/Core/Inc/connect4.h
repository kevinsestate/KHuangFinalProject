#ifndef CONNECT4_H
#define CONNECT4_H

#include <stdint.h>

#define ROWS 6
#define COLS 7



typedef enum {
    DIR_NONE = 0,
    DIR_LEFT,
    DIR_RIGHT
} TouchDirection_t;

extern uint8_t gameMode;

void ShowStartScreen(void);
void WaitForModeSelection(void);


// Input functions
TouchDirection_t GetTouchDirection(void);
uint8_t IsDropPressed(void);

// Drawing functions
void DrawBoard(void);
void DrawToken(uint8_t row, uint8_t col, uint8_t player);

extern uint8_t board[ROWS][COLS];
extern uint8_t currentPlayer;
extern uint8_t selectedCol;

int8_t DropToken(uint8_t col);
uint8_t CheckWin(uint8_t lastRow, uint8_t lastCol);
uint8_t CheckDraw(void);
void DrawCenteredMessage();
#endif // CONNECT4_H

