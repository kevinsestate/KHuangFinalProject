#include "ai.h"
#include "connect4.h"     // for ROWS, COLS, board, CheckWin
#include <string.h>       // for memcpy

int8_t SimulateDrop(uint8_t tempBoard[ROWS][COLS], uint8_t col, uint8_t player) {
    for (int8_t row = ROWS - 1; row >= 0; row--) {
        if (tempBoard[row][col] == 0) {
            tempBoard[row][col] = player;
            return row;
        }
    }
    return -1;
}

int8_t GetSmartAIMove(void) {
    for (uint8_t col = 0; col < COLS; col++) {
        if (board[0][col] != 0) continue;

        uint8_t tempBoard[ROWS][COLS];
        memcpy(tempBoard, board, sizeof(board));
        int8_t row = SimulateDrop(tempBoard, col, 2);
        if (row >= 0 && CheckWin(row, col)) return col;
    }

    for (uint8_t col = 0; col < COLS; col++) {
        if (board[0][col] != 0) continue;

        uint8_t tempBoard[ROWS][COLS];
        memcpy(tempBoard, board, sizeof(board));
        int8_t row = SimulateDrop(tempBoard, col, 1);
        if (row >= 0 && CheckWin(row, col)) return col;
    }

    uint8_t centerOrder[COLS] = {3, 2, 4, 1, 5, 0, 6};
    for (int i = 0; i < COLS; i++) {
        if (board[0][centerOrder[i]] == 0) return centerOrder[i];
    }

    return -1;
}
