#include "connect4.h"
#include "ft6x06.h"
#include "stm32f429i_discovery_ts.h"
#include "stm32f4xx_hal.h"
#include "ai.h"



extern RNG_HandleTypeDef hrng; // use the global RNG handle

// Game board: 0 = empty, 1 = player 1, 2 = player 2
uint8_t gameMode = 0;  // 0 = not selected, 1 = 1P, 2 = 2P
uint32_t startTime = 0;
uint8_t winsP1 = 0;
uint8_t winsP2 = 0;

uint8_t board[ROWS][COLS] = {0};

uint8_t currentPlayer = 1;
uint8_t selectedCol = 3;  // start in middle

#define SCREEN_WIDTH 240
#define ROWS 6
#define COLS 7

#define CELL_WIDTH 30
#define CELL_HEIGHT 30
#define CELL_RADIUS 14

#define GRID_X_OFFSET 15
#define GRID_Y_OFFSET 30



void ShowStartScreen(void) {
    LCD_Clear(0, LCD_COLOR_WHITE);
    LCD_SetFont(&Font16x24);
    LCD_SetTextColor(LCD_COLOR_BLACK);

    // One-Player Button
    const char* p1 = "ONE PLAYER";
    const char* p2 = "TWO PLAYER";

    for (int i = 0; i < strlen(p1); i++) {
        LCD_DisplayChar(30 + i * Font16x24.Width, 100, p1[i]);
    }

    for (int i = 0; i < strlen(p2); i++) {
        LCD_DisplayChar(30 + i * Font16x24.Width, 180, p2[i]);
    }
}

void WaitForModeSelection(void) {
    ShowStartScreen();

    while (gameMode == 0) {
        uint16_t x = 0, y = 0;

        if (ft6x06_ts_detect_touch(FT6206_I2C_ADDR)) {
            ft6x06_ts_get_xy(FT6206_I2C_ADDR, &x, &y);

            if (y > 90 && y < 130) {
                gameMode = 1;  // One-player
            }
            else if (y > 170 && y < 210) {
                gameMode = 2;  // Two-player
            }

            HAL_Delay(300);  // simple debounce
        }
    }

    LCD_Clear(0, LCD_COLOR_WHITE);
    DrawBoard();
}


TouchDirection_t GetTouchDirection(void) {
    uint16_t x = 0, y = 0;
    uint8_t touches = ft6x06_ts_detect_touch(FT6206_I2C_ADDR);

    if (touches > 0) {
        ft6x06_ts_get_xy(FT6206_I2C_ADDR, &x, &y);

        if (x < SCREEN_WIDTH / 2) {
            return DIR_LEFT;
        } else {
            return DIR_RIGHT;
        }
    }

    return DIR_NONE;
}

uint8_t IsDropPressed(void) {
    // PA0 is the user button pin on STM32F429I-DISC1
    return (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET);
}

void DrawBoard(void) {
    LCD_Clear(0, LCD_COLOR_BLUE);  // Grid background

    for (uint8_t row = 0; row < ROWS; row++) {
        for (uint8_t col = 0; col < COLS; col++) {
            uint16_t x_center = GRID_X_OFFSET + col * CELL_WIDTH + CELL_WIDTH / 2;
            uint16_t y_center = GRID_Y_OFFSET + row * CELL_HEIGHT + CELL_HEIGHT / 2;
            LCD_Draw_Circle_Fill(x_center, y_center, CELL_RADIUS, LCD_COLOR_WHITE); // Empty slot = white
        }
    }
}

void DrawToken(uint8_t row, uint8_t col, uint8_t player) {
    if (row >= ROWS || col >= COLS || player == 0) return;

    uint16_t x_center = GRID_X_OFFSET + col * CELL_WIDTH + CELL_WIDTH / 2;
    uint16_t y_center = GRID_Y_OFFSET + row * CELL_HEIGHT + CELL_HEIGHT / 2;
    uint16_t color = (player == 1) ? LCD_COLOR_RED : LCD_COLOR_YELLOW;

    LCD_Draw_Circle_Fill(x_center, y_center, CELL_RADIUS, color);
}


int8_t DropToken(uint8_t col) {
    if (col >= COLS) return -1; // Invalid column

    for (int8_t row = ROWS - 1; row >= 0; row--) {
        if (board[row][col] == 0) {
            board[row][col] = currentPlayer;
            DrawToken(row, col, currentPlayer);
            return row; // Return row where token was placed
        }
    }

    return -1; // Column is full
}

uint8_t CheckWin(uint8_t row, uint8_t col) {
    uint8_t player = board[row][col];
    if (player == 0) return 0;

    // Check in each direction
    int directions[4][2] = {
        {0, 1},   // horizontal →
        {1, 0},   // vertical ↓
        {1, 1},   // diagonal \
        {1, -1}   // anti-diagonal /
    };

    for (int d = 0; d < 4; d++) {
        int count = 1;

        // Check in the positive direction
        int r = row + directions[d][0];
        int c = col + directions[d][1];
        while (r >= 0 && r < ROWS && c >= 0 && c < COLS && board[r][c] == player) {
            count++;
            r += directions[d][0];
            c += directions[d][1];
        }

        // Check in the negative direction
        r = row - directions[d][0];
        c = col - directions[d][1];
        while (r >= 0 && r < ROWS && c >= 0 && c < COLS && board[r][c] == player) {
            count++;
            r -= directions[d][0];
            c -= directions[d][1];
        }

        if (count >= 4) return 1;  // Win
    }

    return 0;  // No win
}


uint8_t CheckDraw(void) {
    for (uint8_t row = 0; row < ROWS; row++)
        for (uint8_t col = 0; col < COLS; col++)
            if (board[row][col] == 0) return 0;
    return 1;
}

void DrawCenteredMessage(const char *msg, uint16_t color) {
    LCD_SetFont(&Font16x24);
    LCD_SetTextColor(color);

    uint16_t charWidth = Font16x24.Width;
    uint16_t msgLen = strlen(msg);
    uint16_t x_start = (LCD_PIXEL_WIDTH - msgLen * charWidth) / 2;
    uint16_t y = 10;

    for (uint16_t i = 0; i < msgLen; i++) {
        LCD_DisplayChar(x_start + i * charWidth, y, msg[i]);
    }
}

uint32_t GetElapsedTimeSeconds(void) {
    return (HAL_GetTick() - startTime) / 1000;
}

void DrawStatusBar(void) {
    char buffer[32];
    LCD_SetFont(&Font16x24);
    LCD_SetTextColor(LCD_COLOR_BLACK);

    // Player wins
    sprintf(buffer, "P1:%d  P2:%d", winsP1, winsP2);
    for (int i = 0; i < strlen(buffer); i++) {
        LCD_DisplayChar(5 + i * Font16x24.Width, 275, buffer[i]);
    }

    // Time
    sprintf(buffer, "Time: %lus", GetElapsedTimeSeconds());
    for (int i = 0; i < strlen(buffer); i++) {
        LCD_DisplayChar(160 + i * Font16x24.Width, 275, buffer[i]);
    }
}

void DrawCenteredMessageAtY(const char *msg, uint16_t y, uint16_t color) {
    LCD_SetFont(&Font16x24);
    LCD_SetTextColor(color);

    uint16_t w = Font16x24.Width;
    uint16_t len = strlen(msg);
    uint16_t x = (LCD_PIXEL_WIDTH - len * w) / 2;

    for (uint16_t i = 0; i < len; i++) {
        LCD_DisplayChar(x + i * w, y, msg[i]);
    }
}


void DrawEndScreen(uint8_t winner, uint32_t timeSeconds) {
    LCD_Clear(0, LCD_COLOR_WHITE);
    LCD_SetFont(&Font16x24);
    LCD_SetTextColor(LCD_COLOR_BLACK);

    char line[32];

    // Show result
    if (winner == 0) {
        sprintf(line, "It's a Draw!");
    } else {
        sprintf(line, "Player %d Wins!", winner);
    }
    DrawCenteredMessage(line, (winner == 1) ? LCD_COLOR_RED : (winner == 2) ? LCD_COLOR_YELLOW : LCD_COLOR_BLACK);

    // Show time
    sprintf(line, "Time: %lus", timeSeconds);
    DrawCenteredMessageAtY(line, 100, LCD_COLOR_BLACK);

    // Show score
    sprintf(line, "Score - P1: %d  P2: %d", winsP1, winsP2);
    DrawCenteredMessageAtY(line, 140, LCD_COLOR_BLACK);

    // Draw restart "button"
    LCD_SetTextColor(LCD_COLOR_BLUE);
    const char *restart = "Play Again";
    for (int i = 0; i < strlen(restart); i++) {
        LCD_DisplayChar(70 + i * Font16x24.Width, 200, restart[i]);
    }
}
